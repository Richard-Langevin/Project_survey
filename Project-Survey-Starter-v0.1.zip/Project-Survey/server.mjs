import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(root, 'data');
const webDir = path.join(root, 'public');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const secret = process.env.SURVEY_SIGNING_KEY || crypto.randomBytes(32).toString('hex');
const presentations = JSON.parse(fs.readFileSync(path.join(dataDir, 'presentations.json'), 'utf8'));
const allowedIds = new Set(presentations.filter(p => p.status === 'approved').map(p => p.id));
const valueChoices = [
  'Generated new ideas or possibilities', 'Provided practical information I can apply',
  'Introduced useful problem-solving approaches', 'Improved my understanding of the subject',
  'Demonstrated valuable real-world applications', 'Introduced new TRIZ methods or innovation concepts',
  'Provided information worth sharing with others', "Offered valuable insights from the speaker's experience",
  'Other', 'Limited value to me'
];
const improvementChoices = [
  'More practical examples or case studies', 'More explanation of key concepts',
  'More technical detail', 'More practical application guidance',
  'Clearer organization or presentation', 'More time for questions and discussion',
  'More supporting visuals or demonstrations', 'More information about results or outcomes',
  'Other', 'No significant improvement needed'
];
const state = {presentationId: null, phase: 'ready'};
const read = (name) => {
  const f = path.join(dataDir, name);
  return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : [];
};
const write = (name, obj) => {
  const f = path.join(dataDir, name);
  const tmp = `${f}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, f);
};
const send = (res, status, payload) => {
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});
  res.end(JSON.stringify(payload));
};
const cleanPresentation = (p) => ({
  id:p.id, speaker:p.speaker, title:p.title, mode:p.mode, photoUrl:p.photoUrl,
  emailAuthorized:p.emailAuthorized, contactEmail:p.emailAuthorized?p.contactEmail:'',
  profileUrl:p.profileUrl
});
const hmac = (content) => crypto.createHmac('sha256', secret).update(content).digest('hex');
const makeToken = (id) => {
  const payload = Buffer.from(JSON.stringify({id, exp:Date.now()+15*60_000, nonce:crypto.randomUUID()})).toString('base64url');
  return `${payload}.${hmac(payload)}`;
};
const checkToken = (token, id) => {
  if (typeof token !== 'string' || token.length > 1024) return null;
  const [payload, signature, extra] = token.split('.');
  if (!payload || !signature || extra || signature.length !== 64) return null;
  if (!crypto.timingSafeEqual(Buffer.from(hmac(payload)), Buffer.from(signature))) return null;
  try {
    const value = JSON.parse(Buffer.from(payload,'base64url').toString('utf8'));
    return value.id === id && Date.now() <= value.exp ? value : null;
  } catch { return null; }
};
const err = (message) => {throw new Error(message);};
function validateSubmission(body) {
  if (!body || !allowedIds.has(body.presentationId)) err('Invalid presentation ID');
  const token = checkToken(body.surveyToken, body.presentationId);
  if (!token) err('Survey access expired or invalid');
  if (typeof body.browserKey !== 'string' || !/^[a-zA-Z0-9-]{20,90}$/.test(body.browserKey)) err('Browser session token required');
  const ratings = body.ratings;
  if (!Array.isArray(ratings) || ratings.length !== 5 || ratings.some(x => !Number.isInteger(x) || x < 1 || x > 5)) err('Answer all five quality ratings');
  if (![1,2,3,4,5].includes(body.perspective)) err('Q6 is required');
  if (![1,2,3,4,5].includes(body.reach)) err('Q7 is required');
  if (!['Yes','No'].includes(body.learn)) err('Q8 is required');
  const checkChoices = (arr, allowed, exclusive) => {
    if (!Array.isArray(arr) || arr.length > 3 || new Set(arr).size !== arr.length || arr.some(x => !allowed.includes(x))) err('Invalid select-up-to-three choices');
    if (arr.includes(exclusive) && arr.length > 1) err('Exclusive answer cannot be combined');
  };
  checkChoices(body.values, valueChoices, 'Limited value to me');
  checkChoices(body.improvements, improvementChoices, 'No significant improvement needed');
  if (!['Yes','No',''].includes(body.volunteer)) err('Invalid Q11 response');
  if (body.email && (body.volunteer !== 'Yes' || typeof body.email !== 'string' || body.email.length > 250 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email))) err('Invalid volunteer email');
  for (const field of ['otherValue','otherImprovement']) {
    if (body[field] && (typeof body[field] !== 'string' || body[field].length > 300)) err('Free-text answer too long');
  }
  return token;
}
async function bodyJSON(req) {
  const chunks = []; let total = 0;
  for await (const part of req) {
    total += part.length; if (total > 20_000) throw new Error('Request too large');
    chunks.push(part);
  }
  try {return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
  catch {throw new Error('Invalid JSON');}
}
const server = http.createServer(async (req,res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method==='GET' && url.pathname==='/api/presentations') return send(res,200,presentations.filter(p=>p.status==='approved').map(cleanPresentation));
    if (req.method==='GET' && url.pathname==='/api/state') return send(res,200,state);
    if (req.method==='POST' && url.pathname==='/api/moderator/state') {
      // DEMO ONLY: must require moderator authentication/CSRF controls before deployment.
      const b=await bodyJSON(req);
      if (!allowedIds.has(b.presentationId) || !['ready','live','feedback'].includes(b.phase)) return send(res,400,{error:'Invalid moderator action'});
      state.presentationId=b.presentationId; state.phase=b.phase;
      const events=read('events.json'); events.push({presentationId:b.presentationId,phase:b.phase,at:new Date().toISOString()});write('events.json',events);
      return send(res,200,state);
    }
    const match=url.pathname.match(/^\/api\/survey\/([A-Za-z0-9-]+)$/);
    if (req.method==='GET' && match) {
      const id=match[1]; const p=presentations.find(p=>p.id===id);
      if (!p || state.presentationId!==id || state.phase!=='feedback') return send(res,403,{error:'Feedback is not currently open for this presentation'});
      return send(res,200,{presentation:cleanPresentation(p),surveyToken:makeToken(id)});
    }
    if (req.method==='POST' && url.pathname==='/api/responses') {
      const b=await bodyJSON(req);let token;
      try {token=validateSubmission(b);} catch (e) {return send(res,400,{error:e.message});}
      const used=read('used-tokens.json');
      if (used.includes(token.nonce)) return send(res,409,{error:'This form was already submitted'});
      const dedupeKey=hmac(`${b.presentationId}|${b.browserKey}`);
      const duplicates=read('dedupe.json');
      if (duplicates.includes(dedupeKey)) return send(res,409,{error:'This browser already submitted feedback for this presentation'});
      const responses=read('responses.json');
      const responseId=`R-${String(responses.length+1).padStart(6,'0')}`;
      responses.push({responseId,presentationId:b.presentationId,at:new Date().toISOString(),source:'ONLINE',
        ratings:b.ratings,perspective:b.perspective,reach:b.reach,learn:b.learn,
        values:b.values,improvements:b.improvements,otherValue:(b.otherValue||'').trim(),
        otherImprovement:(b.otherImprovement||'').trim(),volunteer:b.volunteer});
      // Separate optional contact; do NOT write email to response record or associate it with Response ID.
      if (b.volunteer==='Yes' && b.email) {
        const contacts=read('contacts.json');
        contacts.push({presentationId:b.presentationId,email:b.email.trim(),consent:'Speaker may contact me for additional feedback',date:new Date().toISOString().slice(0,10)});
        write('contacts.json',contacts);
      }
      write('responses.json',responses);
      used.push(token.nonce);write('used-tokens.json',used);
      duplicates.push(dedupeKey);write('dedupe.json',duplicates);
      return send(res,201,{success:true,responseId,contact:cleanPresentation(presentations.find(p=>p.id===b.presentationId))});
    }
    const report=url.pathname.match(/^\/api\/reports\/([A-Za-z0-9-]+)$/);
    if (req.method==='GET' && report) {
      // DEMO ONLY: private speaker reports require access control in production.
      const p=presentations.find(p=>p.id===report[1]);if (!p) return send(res,404,{error:'Unknown presentation'});
      const responses=read('responses.json').filter(r=>r.presentationId===p.id);
      const avg=xs=>xs.length?+(xs.reduce((a,b)=>a+b,0)/xs.length).toFixed(2):null;
      const count=field=>Object.fromEntries([...new Set(responses.flatMap(r=>r[field]))].map(v=>[v,responses.filter(r=>r[field].includes(v)).length]));
      const n=responses.length;
      return send(res,200,{presentation:cleanPresentation(p),n,
        qualityAverage:avg(responses.map(r=>r.ratings.reduce((a,b)=>a+b,0)/5)),
        qualityByQuestion:[0,1,2,3,4].map(i=>avg(responses.map(r=>r.ratings[i]))),
        changeInPerspective:avg(responses.map(r=>r.perspective)),
        potentialReach:avg(responses.map(r=>r.reach)),
        learnMorePercent:n?Math.round(responses.filter(r=>r.learn==='Yes').length*100/n):null,
        values:count('values'),improvements:count('improvements')});
    }
    if (req.method==='GET') {
      const relative=url.pathname==='/'?'index.html':decodeURIComponent(url.pathname.slice(1));
      const file=path.resolve(webDir,relative);
      if (file!==webDir && !file.startsWith(webDir+path.sep)) return send(res,403,{error:'Invalid file path'});
      if (fs.existsSync(file) && fs.statSync(file).isFile()) {
        const ext=path.extname(file).toLowerCase(); const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'};
        res.writeHead(200,{'content-type':types[ext]||'application/octet-stream','cache-control':'no-store','x-content-type-options':'nosniff'});
        return fs.createReadStream(file).pipe(res);
      }
    }
    return send(res,404,{error:'Not found'});
  } catch(e) {send(res,400,{error:e.message||'Request failed'});}
});
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  server.listen(PORT, HOST, () => console.log(`Project Survey DEMO at http://${HOST}:${PORT}`));
}
export {server};
