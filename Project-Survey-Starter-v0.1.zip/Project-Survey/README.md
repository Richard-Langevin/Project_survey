# Project Survey

**TRIZCON2026 Individual Speaker Feedback System** — Version 3.0 beta baseline / implementation prototype v0.1.

Developed as a starter project for the **Altshuller Institute for TRIZ Studies** conference workflow. This is **not a production system** and contains only fictional speaker data.

## What works in this prototype

- A single-room moderator can select the **actual** presentation, including a substitute presenter.
- All approved presentations have distinct IDs and pre-generated QR images.
- The moderator can switch between **ready → live → feedback**; only the chosen presentation's survey can be opened while feedback is active.
- An attendee can complete the agreed Q1–Q11 survey on a phone or desktop. Required: Q1–Q8; optional: Q9–Q11.
- Q9/Q10 allow up to three selections and enforce mutually exclusive “limited/no improvement” choices.
- A 15-minute signed form token lets an attendee finish a survey already opened even if the moderator moves on.
- Home Base (the local Node server) validates, records, and deduplicates submissions on a best-effort per-browser basis.
- Volunteer email is saved apart from anonymous response rows, with no Response ID in contact records.
- The developmental speaker report calculates response counts, averages, and choice frequencies without ranking speakers.
- An activity record logs the moderator's state changes.

## Start (Node.js 18+; no npm install required)

```bash
npm start
```

Open **http://localhost:3000** in a browser. On the Moderator tab, select a fictional presentation and click **Display feedback QR**. Click **Attendee survey** to fill out a test response, then view **Speaker reports**.

The included QR images link to `http://localhost:3000`, which is only suitable for a browser on the same computer. For phone-based tests, the app must be reachable from the phone, and the QR target must be regenerated:

```bash
pip install 'qrcode[pil]'
python scripts/generate_qr.py --base-url http://<YOUR-LAN-IP>:3000
HOST=0.0.0.0 npm start
```

A LAN-exposed demo is **not secured**. Use a private, isolated testing network, fictional data, and avoid Internet exposure. Production requires HTTPS, authentication, access controls and managed storage before any public launch.

## Test

```bash
npm test
```

## Preparing real speaker data

`data/presentations.json` contains **fictional fixtures**. Do not overwrite it with real speaker data until we inspect the existing Abstract Submission Database and confirm field mappings, acceptance status, marketing/contact permissions, and secure storage. One speaker can have several presentation IDs. Schedule and Presentation ID are separate. QR codes belong to presentations, never time slots.

## Roadmap

**Milestone 1 — Frontend:** Import confirmed presentations from existing abstract records, verify unique IDs, final titles/photographs, generate QR assets, moderator screen, substitution/correction log, test one presentation room.

**Milestone 2 — Survey integration:** Final Q1–Q11 survey, speaker/photo confirmation, five-minute projector display, accessible mobile controls, post-submit resource links, paper backup.

**Milestone 3 — Backend:** Authenticated API, managed database, clear retention policy, stronger dedupe and consent design, independent contact store, durable processing, monitoring and recovery, CSV/scannable paper import.

**Milestone 4 — Reports and validation:** Confidential individual speaker feedback report, internal aggregate programming insights, end-to-end beta timing (60–90-second target), substitution and network-loss drills.

## Important limitations

- **Prototype security is intentionally incomplete**: moderator actions and reports are not authenticated. Never deploy publicly or collect actual attendee/contact data here.
- This server stores local JSON files and does not have backups, transactional writes, encryption at rest, or reliable cross-process synchronization.
- Browser-local deduplication is not proof of one human/one response and can be bypassed using other devices or cleared storage.
- A QR code is displayed for about five minutes operationally, but the demo has **no automatic projector timer**; moderator manages state manually.
- QR links remain shareable. New survey access is denied when feedback is not active; already opened forms have a signed completion window.
- No pre-existing abstract database is connected yet. Presenter images, contacts, abstract import, paper scan/OMR, and production data permissions await validation.
- Email action clicks are not proof messages were sent; contact actions are not yet tracked.
- No final hosting platform or privacy/ownership/retention policy has been approved.

See [architecture](docs/architecture.md), [development record](docs/master-development-record.md), [data dictionary](docs/data-dictionary.md), and [beta test plan](docs/beta-test-plan.md).
