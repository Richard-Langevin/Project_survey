import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'project-survey-test-'));
fs.copyFileSync(new URL('../data/presentations.json', import.meta.url), path.join(temporary,'presentations.json'));
process.env.DATA_DIR = temporary;
const {server} = await import('../server.mjs');
const call=async (base,url,method='GET',body)=>{const res=await fetch(base+url,{method,headers:body?{'content-type':'application/json'}:{},body:body?JSON.stringify(body):undefined});return {status:res.status,data:await res.json()}};

test('one-room presentation selection, survey validation, duplicate and report aggregation',async()=>{
  server.listen(0,'127.0.0.1');await once(server,'listening');
  const base=`http://127.0.0.1:${server.address().port}`;
  try{
    const ps=await call(base,'/api/presentations');assert.equal(ps.status,200);assert.equal(ps.data.length,2);
    let result=await call(base,'/api/survey/D1-S01');assert.equal(result.status,403);
    result=await call(base,'/api/moderator/state','POST',{presentationId:'D1-S02',phase:'feedback'});assert.equal(result.status,200);
    result=await call(base,'/api/survey/D1-S02');assert.equal(result.status,200);
    const key='beta-browser-key-22222222';const payload={presentationId:'D1-S02',surveyToken:result.data.surveyToken,browserKey:key,ratings:[5,4,5,4,5],perspective:4,reach:5,learn:'Yes',values:['Generated new ideas or possibilities'],improvements:['No significant improvement needed'],volunteer:'No',email:'',otherValue:'',otherImprovement:''};
    const invalid=await call(base,'/api/responses','POST',{...payload,values:['Limited value to me','Generated new ideas or possibilities']});assert.equal(invalid.status,400);
    const submitted=await call(base,'/api/responses','POST',payload);assert.equal(submitted.status,201);assert.ok(submitted.data.responseId.startsWith('R-'));
    const duplicate=await call(base,'/api/responses','POST',payload);assert.equal(duplicate.status,409);
    const report=await call(base,'/api/reports/D1-S02');assert.equal(report.status,200);assert.equal(report.data.n,1);assert.equal(report.data.qualityAverage,4.6);assert.equal(report.data.learnMorePercent,100);
  }finally{server.close();fs.rmSync(temporary,{recursive:true,force:true})}
});
