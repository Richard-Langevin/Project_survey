"""Generate a QR image per approved presentation.
Usage: python scripts/generate_qr.py --base-url http://localhost:3000
To scan from phones, use a reachable HTTPS domain or local-LAN host URL.
Requires Python 'qrcode' package: pip install 'qrcode[pil]'.
"""
import argparse
import json
from pathlib import Path
from urllib.parse import quote
import qrcode

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--base-url',default='http://localhost:3000')
args=parser.parse_args()
base=args.base_url.rstrip('/')
if not base.startswith(('https://','http://')): raise SystemExit('base URL needs http or https')
records=json.loads((root/'data/presentations.json').read_text())
folder=root/'public/qr'
folder.mkdir(parents=True,exist_ok=True)
for p in records:
    if p['status']!='approved': continue
    link=f"{base}/?survey={quote(p['id'])}"
    img=qrcode.make(link)
    img.save(folder/f"{p['id']}.png")
    print(p['id'],link)
