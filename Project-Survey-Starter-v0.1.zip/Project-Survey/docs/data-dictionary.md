# Initial Data Dictionary (beta draft)

All field details to be reconciled with the actual Abstract Submission Database.

| Dataset | Field(s) | Purpose | Sensitive? |
| --- | --- | --- | --- |
| Presentation Master | `id` (e.g. D1-S01) | Stable join key across QR, survey, report | No |
| Presentation Master | `submissionId`, `speaker`, `title`, `abstract` | Imported from existing accepted abstracts | Speaker data |
| Presentation Master | `photoUrl`, `mode`, `status`, `scheduledTime` | Correct display and operational planning | Speaker data |
| Presentation Master | `emailAuthorized`, `contactEmail`, `profileUrl` | Authorized post-survey presenter contact | Yes; publish only if authorized |
| Evaluation | `responseId`, `presentationId`, `at`, `source` | Audit and report association | Pseudonymous event data |
| Evaluation | `ratings` array Q1–Q5 | 1–5, common Poor→Excellent scale | No |
| Evaluation | `perspective` Q6 | 1–5 No Change→Major Change | No |
| Evaluation | `reach` Q7 | 1–5 Limited→Broad Community Benefit | No |
| Evaluation | `learn` Q8 | Yes / No | No |
| Evaluation | `values` Q9 | 0–3 approved choices; limited value exclusive | No |
| Evaluation | `improvements` Q10 | 0–3 approved choices; no improvement exclusive | No |
| Evaluation | `otherValue`, `otherImprovement` | Optional max 300 chars each; may include identifying text | Potentially |
| Evaluation | `volunteer` Q11 | Yes/No/blank; email never in same row | Potentially linkable |
| Volunteer Contact | `presentationId`, `email`, `consent`, `date` | Optional independent follow-up record | Yes — protect separately |
| Dedupe ledger | Hash(Presentation ID + random browser key) | Best-effort duplicate detection | Pseudonymous, access restricted |
| Used-token ledger | nonce | Prevent replay of issued form token | Not attendee identity |
| Moderator events | `presentationId`, `phase`, `at` | Audit changed speaker/timing | Operational |

**Score:** Quality = arithmetic mean of Q1–Q5 *per attendee*, then mean across responses. Q6/Q7 separate 1–5 means. Q8 = percentage of Yes out of Yes/No answers. Q9/Q10 = counts and percentages of attendees who selected each choice (multiple selections per attendee, so percentages can exceed 100% in total). Never rank speakers. Display N and avoid strong inference from small N.
