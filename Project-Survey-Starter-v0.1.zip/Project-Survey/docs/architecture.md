# System architecture — initial specification

## Desired function

Capture timely, anonymous feedback on the presentation actually delivered, associate the feedback to the correct presentation, and create developmental reports without additional speaker re-registration.

## Three components

1. **Before session:** existing Abstract Submission data -> approved presentations -> Presentation Master (one presentation per row) -> QR code per Presentation ID -> single-room Moderator Console.
2. **During transition:** moderator selects the actual speaker, displays correct presentation title/photo/QR for ~5 min -> attendee scans -> confirms speaker -> responds to Q1–Q11 in ~60–90 sec -> Submit.
3. **After response:** Home Base validates -> records Response ID & Presentation ID -> separate volunteer contact (if opted in) -> developmental report for speaker; internal conference analysis for Institute.

## Presentation lifecycle

- Approved: in master list with assigned stable Presentation ID and QR.
- Ready: moderator chooses speaker who will actually present.
- Live: moderator records presentation underway.
- Feedback: moderator displays QR and opens new feedback forms.
- Closed: moderator changes state; already open forms may complete within server-issued token expiry.

A changed schedule never changes the Presentation ID. A substitute is selected from the approved list. If an unscheduled speaker must present, an authorized admin needs a reviewed manual record-creation process (not in prototype). Only one room and one selected active presentation at a time.

## Minimum data separation

- Presentation Master: identifiable speaker metadata sourced from approved abstract data (not public attendee answers).
- Anonymous evaluation responses: Presentation ID, generated Response ID, Q1–Q11 answer values, date/time, response source. No attendee names/emails.
- Volunteer contact: Presentation ID, voluntarily supplied email and consent; **no Response ID or response details**. Minimize joinable timestamps; strictly restrict access and consider a stand-alone post-survey contact form during privacy review.
- Duplicate ledger: hashed per-browser token + presentation combination; never placed in the speaker report.
- Moderator audit events: Presentation ID, action, time; production must also identify authorized operator.

## Technical limitations still needing resolution

Authentication/authorization; privacy and consent text; event-based response cutoff; durable persistence; contact record risk of re-identification in very small samples; duplicate exceptions; QR image final URL; mobile accessibility; offline/paper scans; report access security; document retention and deletion.

## TRIZ design principle

Define the required function first. Use resources that already exist, including the Abstract Submission Database and moderator's knowledge of the actual presenter. Do not identify attendees when the task is to detect a repeated evaluation of the same presentation. Protect system function rather than dependence on QR/Wi-Fi; retain paper fallback.
