# Beta Test Plan — Project Survey

## Test participants

6–10 fictional attendees on mixed iOS/Android/desktop browsers; one moderator; one mock online speaker unable to connect; one alternate speaker. Use fake names and fake email domains (example.com).

## Script

1. Moderator selects Speaker A, clicks Start, then Display QR; verify picture/name/title/Presentation ID, QR scan and opened survey match.
2. Each participant completes Q1–Q11. Time start-to-submit, record accessibility problems, and whether answers were clear.
3. Moderator changes to Speaker B while first attendee still completes an already opened form; verify first submission reaches A and new QR points to B.
4. Attempt a second submission from same browser and Presentation ID; document the warning and the limits of best-effort deduplication.
5. Force technical interruption of the simulated online Speaker B; moderator selects an alternate prepared presenter; verify no stale attribution.
6. Try invalid answers and contradictory Q9/Q10 selections; verify server rejects invalid records.
7. Simulate QR/Wi-Fi failure; use prepared paper forms and compare intake flow (paper scanner import is **not** implemented yet).
8. Validate developmental report counts, Q1–Q5 quality, Q6/Q7, Q8 interest %, and Q9/Q10 frequencies against hand-calculated results.
9. Confirm that no voluntary email appears in response rows or speaker reports; test access restrictions **after implemented**.

## Beta thresholds (proposed; revise after observing tests)

- Target typical attendee survey completion within 90 seconds, with no more than 120 seconds for most test users.
- 100% of accepted test feedback attributed to correct actual presentation.
- Zero failed accepted submissions under normal connected testing.
- Zero speaker report inclusion of volunteer email or attendee tracking token.
- No silent loss of responses and clear acknowledgement only after server has accepted them.
- Paper contingency usable by moderator without complex technical instructions.

## Beta feedback and versioning

Record test case, observer, actual outcome, issue severity, proposed change, approval decision, and resulting version (3.0 -> 3.1). Preserve rejected changes and rationale. Do not overwrite the Q9 baseline without evidence and approval.
