# Master Development Record — Project Survey

**Working title:** TRIZCON2026 Individual Speaker Feedback System — Project Survey
**Baseline:** Survey content v3.0 (Q9 approved); implementation prototype v0.1.
**Date:** October 12, 2026.
**Project stakeholder:** Altshuller Institute for TRIZ Studies. Final code/data intellectual-property designation and data-controller roles to be confirmed before external collaboration.

## Purpose

Capture immediate, anonymous, useful audience reaction to presentations, provide confidential developmental Speaker Feedback Reports, and derive Institute-wide conference programming insights without speaker rankings.

## Approved design decisions

- Single conference presentation room -> one active Moderator Console.
- Speaker abstract, photo, and existing submitted details come from the Abstract Submission Database; no repeated speaker intake by default.
- Each approved **presentation**, not person/time slot, receives a stable Presentation ID and unique prepared QR code.
- Moderator selects who **actually** speaks and activates that presentation's QR; substitutions need no QR regeneration if that presentation is already approved.
- After the talk, display speaker photograph/title/name and QR on projector about five minutes; survey appears on phone and targets 60–90-second completion.
- Anonymous attendee survey: no required name/email/Attendee ID. Q11 optional volunteer email stored separately.
- Best-effort anonymous duplicate prevention per presentation; don't pretend this definitively identifies a person.
- Q1–Q5 measure quality; Q6 perspective change; Q7 potential reach; Q8 desire to learn more; Q9 specific value received; Q10 improvement opportunities; Q11 volunteer feedback.
- Q9 wording **approved**: “What value did this presentation provide to you? Select up to 3.” Ten approved options are encoded in public/app.js and server.mjs. Adjust only based on beta evidence.
- Report is developmental, not competitive; speaker ranking is excluded.
- QR/Wi-Fi outage plan includes physical backup forms and pencils, with later machine-assisted import planned.

## Considered and rejected approaches

- Separate speaker re-registration despite existing accepted abstracts: avoid duplicate input.
- Bind QR to fixed scheduled slot: fragile under speaker substitutions.
- Require attendee ID/name for feedback: unnecessary for core function and anonymity.
- Institute-mediated general follow-up email for Q8: speaker resource page preferred.
- Q9 as only emotional reaction or purely presentation ingredient question: replaced by structured value categories.
- Rank speakers or benchmark them against each other: rejected for developmental purpose.

## Current implementation status

- Working local demonstration using Node built-ins and fictional speaker fixtures, moderator state, signed survey access, per-browser dedupe, isolated volunteer contacts and report aggregation.
- **Not deployed or connected** to existing abstracts, GitHub, live database, or conference operations.
- Critical security and operations work is still required; this demo must not collect real submissions.

## Next steps

1. Confirm where existing abstract records reside and retrieve approved export safely; inspect fields/consents.
2. Map authoritative fields, accepted status, final titles/photos and alternate-speaker procedures.
3. Decide production data platform, operator authentication and hosting domain.
4. Implement moderator correction history, survey display timer, genuine QR link generation, and reliable final submission window.
5. Build secure contact consent workflow, duplicate policy, private reports and paper-scan import.
6. Beta-test with fictional participants including substitution, low connectivity and time measurements; record results and revise under version control.

## Change log

- **v3.0 survey baseline:** refined Q9 approved for beta; user explicitly permits evidence-based revision after beta.
- **Architecture revision:** moderator selects actual presentation from all approved presentations; single-room control.
- **Implementation v0.1:** initial working local prototype and documentation created, awaiting publishing to requested GitHub repository.
